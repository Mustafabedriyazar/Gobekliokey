/* GÖBEK17 v170 multiplayer SDK — ranked matchmaking + account-authenticated rooms. */
(function(g){'use strict';
  function base(v){return String(v||'').replace(/\/+$/,'')}
  function rid(){try{if(g.crypto&&crypto.randomUUID)return crypto.randomUUID()}catch(_){}return 'a'+Date.now().toString(36)+Math.random().toString(36).slice(2)}
  function secret(){try{if(g.crypto&&g.crypto.getRandomValues){var a=new Uint8Array(24);g.crypto.getRandomValues(a);return Array.from(a,function(x){return x.toString(16).padStart(2,'0')}).join('')}}catch(_){}return rid()+rid()+rid()}
  function Client(endpoint){this.endpoint=base(endpoint||g.location.origin);this.roomId=null;this.seat=null;this.token=null;this.accountToken=null;this.refreshToken=null;this.account=null;this.connectionId=rid();this.snapshot=null;this.listeners=[];this.abort=null;this.connected=false}
  Client.prototype._headers=function(kind){var h={'Content-Type':'application/json','X-G17-Connection':this.connectionId},t=kind==='account'?this.accountToken:this.token;if(t)h.Authorization='Bearer '+t;return h};
  Client.prototype._json=async function(path,opt){opt=opt||{};var ownerRetry=!!opt._ownerRetry,authKind=opt._auth||'seat',req=Object.assign({},opt);delete req._ownerRetry;delete req._auth;req.headers=Object.assign({},this._headers(authKind),req.headers||{});var ac=null,timer=0;if(!req.signal&&typeof AbortController!=='undefined'){ac=new AbortController();req.signal=ac.signal;timer=setTimeout(function(){try{ac.abort()}catch(_){}},12000)}try{var r=await fetch(this.endpoint+path,req),j=await r.json();j.httpStatus=r.status;if(!ownerRetry&&j&&j.err==='ROOM_OWNER_MISMATCH'&&j.ownerUrl){this.endpoint=base(j.ownerUrl);var retry=Object.assign({},opt,{_ownerRetry:true});return this._json(path,retry)}return j}finally{if(timer)clearTimeout(timer)}};
  Client.prototype.setAccountSession=function(x){x=x||{};this.accountToken=x.accessToken||null;this.refreshToken=x.refreshToken||null;this.account=x.user||null;return this};
  Client.prototype.register=async function(username,password,displayName,email){var j=await this._json('/v1/auth/register',{method:'POST',_auth:'account',body:JSON.stringify({username:username||'',email:email||'',password:password,displayName:displayName})});if(j.ok)this.setAccountSession(j);return j};
  Client.prototype.login=async function(identity,password){var j=await this._json('/v1/auth/login',{method:'POST',_auth:'account',body:JSON.stringify({identity:identity,password:password})});if(j.ok)this.setAccountSession(j);return j};
  Client.prototype.refreshAuth=async function(){if(!this.refreshToken)return{ok:false,err:'NO_REFRESH'};var j=await this._json('/v1/auth/refresh',{method:'POST',_auth:'account',body:JSON.stringify({refreshToken:this.refreshToken})});if(j.ok)this.setAccountSession(j);return j};
  Client.prototype.me=async function(){return this._json('/v1/auth/me',{method:'GET',_auth:'account'})};
  Client.prototype.logoutAuth=async function(){var j=await this._json('/v1/auth/logout',{method:'POST',_auth:'account',body:JSON.stringify({refreshToken:this.refreshToken})});this.accountToken=null;this.refreshToken=null;this.account=null;return j};
  Client.prototype.recoverAccount=async function(identity,recoveryCode,newPassword){var j=await this._json('/v1/auth/recover',{method:'POST',_auth:'account',body:JSON.stringify({identity:identity,recoveryCode:recoveryCode,newPassword:newPassword})});if(j.ok)this.setAccountSession(j);return j};
  Client.prototype.changePassword=async function(currentPassword,newPassword){var j=await this._json('/v1/auth/password',{method:'POST',_auth:'account',body:JSON.stringify({currentPassword:currentPassword,newPassword:newPassword})});if(j.ok)this.setAccountSession(j);return j};
  Client.prototype.rotateRecoveryCodes=async function(){return this._json('/v1/auth/recovery-codes',{method:'POST',_auth:'account',body:'{}'})};
  Client.prototype.getProfile=async function(){return this._json('/v1/profile/me',{method:'GET',_auth:'account'})};
  Client.prototype.updateProfile=async function(bio,avatar){return this._json('/v1/profile/me',{method:'POST',_auth:'account',body:JSON.stringify({bio:bio,avatar:avatar})})};
  Client.prototype.getPublicProfile=async function(playerId){return this._json('/v1/players/'+encodeURIComponent(playerId)+'/profile',{method:'GET',_auth:'account'})};
  Client.prototype.enqueueQuickMatch=async function(mode){return this._json('/v1/quickmatch/enqueue',{method:'POST',_auth:'account',body:JSON.stringify({mode:mode||'TEAM'})})};
  Client.prototype.quickMatchStatus=async function(){return this._json('/v1/quickmatch/status',{method:'GET',_auth:'account'})};
  Client.prototype.cancelQuickMatch=async function(){return this._json('/v1/quickmatch/cancel',{method:'POST',_auth:'account',body:'{}'})};
  Client.prototype.enqueueMatchmaking=async function(mode){return this._json('/v1/matchmaking/enqueue',{method:'POST',_auth:'account',body:JSON.stringify({mode:mode||'TEAM'})})};
  Client.prototype.matchmakingStatus=async function(){return this._json('/v1/matchmaking/status',{method:'GET',_auth:'account'})};
  Client.prototype.cancelMatchmaking=async function(){return this._json('/v1/matchmaking/cancel',{method:'POST',_auth:'account',body:'{}'})};
  Client.prototype.getRankedLeaderboard=async function(mode,limit){return this._json('/v1/ranked/leaderboard?mode='+encodeURIComponent(mode||'TEAM')+'&limit='+encodeURIComponent(limit||50),{method:'GET',_auth:'account'})};
  Client.prototype.createRoom=async function(mode,context){return this._json('/v1/rooms',{method:'POST',_auth:'account',body:JSON.stringify({mode:mode||'TEAM',context:context||'CASUAL'})})};
  Client.prototype.joinRoom=async function(roomId,name,preferredSeat){var jt=secret(),jid=rid(),body=JSON.stringify({name:name||'OYUNCU',preferredSeat:preferredSeat,clientToken:jt,clientJoinId:jid}),j;try{j=await this._json('/v1/rooms/'+encodeURIComponent(roomId)+'/join',{method:'POST',_auth:'account',body:body})}catch(e){j=await this._json('/v1/rooms/'+encodeURIComponent(roomId)+'/join',{method:'POST',_auth:'account',body:body})}if(j.ok){this.roomId=j.roomId;this.seat=j.seat;this.token=jt;this.snapshot=j.snapshot||null}return j};
  Client.prototype.reclaimRoom=async function(roomId){if(!this.accountToken)return{ok:false,err:'AUTH_REQUIRED'};var jt=secret(),j=await this._json('/v1/rooms/'+encodeURIComponent(roomId)+'/reclaim',{method:'POST',_auth:'account',body:JSON.stringify({clientToken:jt})});if(j.ok){this.roomId=j.roomId;this.seat=j.seat;this.token=jt;this.snapshot=j.snapshot||null}return j};
  Client.prototype.reportPlayer=async function(roomId,reportedSeat,category,note,messageId){return this._json('/v1/mod/report',{method:'POST',_auth:'account',body:JSON.stringify({roomId:roomId,reportedSeat:reportedSeat,category:category||'OTHER',note:note||'',messageId:messageId||''})})};
  Client.prototype.sendChat=async function(text,kind){if(!this.roomId||!this.token)return{ok:false,err:'JOIN_REQUIRED'};var j=await this._json('/v1/rooms/'+encodeURIComponent(this.roomId)+'/chat',{method:'POST',body:JSON.stringify({text:text,kind:kind||'text'})});if(j.snapshot)this._emit(j.snapshot);return j};
  Client.prototype.getSnapshot=async function(){var j=await this._json('/v1/rooms/'+encodeURIComponent(this.roomId)+'/snapshot');if(j.ok)this._emit(j.snapshot);return j};
  Client.prototype.onSnapshot=function(fn){if(typeof fn==='function')this.listeners.push(fn);return this};
  Client.prototype._emit=function(s){if(!s)return false;var cur=this.snapshot;if(cur&&Number.isInteger(cur.rev)&&Number.isInteger(s.rev)){if(s.rev<cur.rev)return false;if(s.rev===cur.rev){if(Number.isInteger(cur.eventSeq)&&Number.isInteger(s.eventSeq)&&s.eventSeq<cur.eventSeq)return false;if(Number(s.serverTime||0)<Number(cur.serverTime||0))return false}}this.snapshot=s;for(var i=0;i<this.listeners.length;i++)try{this.listeners[i](s)}catch(_){}return true};
  /* v151: caller may pin the logical action id + base revision. This lets the table bridge
     safely retry a transport failure without ever creating a second logical move. */
  Client.prototype.action=async function(type,payload,opts){opts=opts||{};if(!this.snapshot)await this.getSnapshot();var a=Object.assign({type:type},payload||{}),rev=Number.isInteger(opts.expectedRev)?opts.expectedRev:this.snapshot.rev,aid=String(opts.clientActionId||rid());var j=await this._json('/v1/rooms/'+encodeURIComponent(this.roomId)+'/action',{method:'POST',body:JSON.stringify({expectedRev:rev,clientActionId:aid,action:a})});j.clientActionId=aid;if(j.snapshot)this._emit(j.snapshot);return j};
  Client.prototype.reconnect=async function(){var j=await this._json('/v1/rooms/'+encodeURIComponent(this.roomId)+'/reconnect',{method:'POST',body:'{}'});if(j.snapshot)this._emit(j.snapshot);return j};
  Client.prototype.disconnect=async function(){this.closeEvents();if(!this.roomId||!this.token)return{ok:true};return this._json('/v1/rooms/'+encodeURIComponent(this.roomId)+'/disconnect',{method:'POST',body:'{}'})};
  Client.prototype.closeEvents=function(){if(this.abort){try{this.abort.abort()}catch(_){}this.abort=null}this.connected=false};
  Client.prototype.connectEvents=async function(){
    this.closeEvents();if(!this.roomId||!this.token)throw new Error('JOIN_REQUIRED');
    var self=this,ac=new AbortController();this.abort=ac;
    var r=await fetch(this.endpoint+'/v1/rooms/'+encodeURIComponent(this.roomId)+'/events',{headers:{Authorization:'Bearer '+this.token,'X-G17-Connection':this.connectionId,Accept:'text/event-stream'},signal:ac.signal});
    if(!r.ok)throw new Error('EVENT_STREAM_'+r.status);this.connected=true;
    var rd=r.body.getReader(),dec=new TextDecoder(),buf='';
    try{while(true){var q=await rd.read();if(q.done)break;buf+=dec.decode(q.value,{stream:true});var cut;while((cut=buf.indexOf('\n\n'))>=0){var block=buf.slice(0,cut);buf=buf.slice(cut+2);var lines=block.split(/\r?\n/),ev='',data='';for(var i=0;i<lines.length;i++){if(lines[i].indexOf('event:')===0)ev=lines[i].slice(6).trim();else if(lines[i].indexOf('data:')===0)data+=lines[i].slice(5).trim()}if(ev==='snapshot'&&data){try{self._emit(JSON.parse(data))}catch(_){}}}}}
    catch(e){if(!ac.signal.aborted)throw e}finally{if(this.abort===ac)this.abort=null;this.connected=false}
  };
  g.G17MP={Client:Client,protocol:'G17MP/1',build:'gobek17-182-v182-real-account-quickmatch'};
})(window);
