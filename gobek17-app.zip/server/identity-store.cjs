'use strict';
const fs=require('fs');
const path=require('path');

function clone(v){return v==null?v:JSON.parse(JSON.stringify(v))}
function defaultProfile(accountId){return{accountId,createdAt:Date.now(),updatedAt:Date.now(),bio:'',avatar:'default',stats:{matches:0,wins:0,ties:0,hands:0,handWins:0,bigWins:0,totalPenalty:0,majorCount:0,processPenalty:0},wallet:{chips:100000,gems:500}}}
function mergeProfile(p,accountId){const d=defaultProfile(accountId),x=p||{};return{...d,...clone(x),accountId,stats:{...d.stats,...clone(x.stats||{})},wallet:{...d.wallet,...clone(x.wallet||{})}}}
class FileIdentityStore{
  constructor(opts={}){
    const envFile=process.env.G17_IDENTITY_FILE,envDir=process.env.G17_DATA_DIR;
    const dir=envDir||path.join(__dirname,'.g17-state'),v165=path.join(dir,'identity-v165.json'),v164=path.join(dir,'identity-v164.json');
    this.file=path.resolve(opts.file||envFile||(fs.existsSync(v165)?v165:(fs.existsSync(v164)?v164:v165)));
    this.enabled=opts.enabled==null?String(process.env.G17_IDENTITY_PERSISTENCE||'1')!=='0':!!opts.enabled;
    this.state={format:'G17IDENTITY/1',users:{},usernames:{},publicIds:{},sessions:{},refresh:{},sanctions:{},reports:[],profiles:{},recovery:{},walletTx:{},processedMatches:{}};
    this.lastSavedAt=0;this.lastError=null;this.connected=true;
  }
  async connect(){if(!this.enabled)return true;try{if(fs.existsSync(this.file)){const raw=JSON.parse(fs.readFileSync(this.file,'utf8'));if(raw&&raw.format==='G17IDENTITY/1')this.state=Object.assign(this.state,raw)}this.state.profiles=this.state.profiles||{};this.state.recovery=this.state.recovery||{};this.state.walletTx=this.state.walletTx||{};this.state.processedMatches=this.state.processedMatches||{};this.lastError=null;return true}catch(e){this.lastError=String(e&&e.message||e);throw e}}
  async close(){if(this.enabled)await this._save();this.connected=false}
  _ensure(){fs.mkdirSync(path.dirname(this.file),{recursive:true,mode:0o700})}
  async _save(){if(!this.enabled)return true;try{this._ensure();const data=JSON.stringify({...this.state,savedAt:Date.now()}),tmp=this.file+'.tmp-'+process.pid+'-'+Date.now();const fd=fs.openSync(tmp,'w',0o600);try{fs.writeFileSync(fd,data,'utf8');fs.fsyncSync(fd)}finally{fs.closeSync(fd)}fs.renameSync(tmp,this.file);try{fs.chmodSync(this.file,0o600)}catch(_){}this.lastSavedAt=Date.now();this.lastError=null;return true}catch(e){this.lastError=String(e&&e.message||e);throw e}}
  async createUser(u){if(this.state.usernames[u.username])return false;this.state.users[u.id]=clone(u);this.state.usernames[u.username]=u.id;this.state.publicIds[u.publicId]=u.id;this.state.profiles[u.id]=mergeProfile(null,u.id);await this._save();return true}
  async getUserByName(n){const id=this.state.usernames[n];return id?clone(this.state.users[id]||null):null}
  async getUserById(id){return clone(this.state.users[id]||null)}
  async getUserByPublicId(pid){const id=this.state.publicIds[pid];return id?clone(this.state.users[id]||null):null}
  async updateUser(u){if(!u||!this.state.users[u.id])return false;this.state.users[u.id]=clone(u);this.state.usernames[u.username]=u.id;this.state.publicIds[u.publicId]=u.id;await this._save();return true}
  async putSession(hash,s,ttlMs){this.state.sessions[hash]={...clone(s),exp:Date.now()+ttlMs};await this._save();return true}
  async getSession(hash){const s=this.state.sessions[hash];if(!s)return null;if(Number(s.exp)<=Date.now()){delete this.state.sessions[hash];await this._save();return null}return clone(s)}
  async deleteSession(hash){const ok=!!this.state.sessions[hash];delete this.state.sessions[hash];if(ok)await this._save();return ok}
  async putRefresh(hash,s,ttlMs){this.state.refresh[hash]={...clone(s),exp:Date.now()+ttlMs};await this._save();return true}
  async getRefresh(hash){const s=this.state.refresh[hash];if(!s)return null;if(Number(s.exp)<=Date.now()){delete this.state.refresh[hash];await this._save();return null}return clone(s)}
  async deleteRefresh(hash){const ok=!!this.state.refresh[hash];delete this.state.refresh[hash];if(ok)await this._save();return ok}
  async revokeAccountSessions(accountId){let n=0;for(const [h,s] of Object.entries(this.state.sessions))if(s.accountId===accountId){delete this.state.sessions[h];n++}for(const [h,s] of Object.entries(this.state.refresh))if(s.accountId===accountId){delete this.state.refresh[h];n++}if(n)await this._save();return n}
  async getSanction(accountId){return clone(this.state.sanctions[accountId]||null)}
  async setSanction(accountId,s){if(s)this.state.sanctions[accountId]=clone(s);else delete this.state.sanctions[accountId];await this._save();return true}
  async addReport(r){this.state.reports.push(clone(r));if(this.state.reports.length>5000)this.state.reports.splice(0,this.state.reports.length-5000);await this._save();return true}
  async listReports(limit=100){return clone(this.state.reports.slice(-Math.max(1,Math.min(500,limit))).reverse())}
  async getRecoveryHashes(accountId){return clone(this.state.recovery[accountId]||[])}
  async setRecoveryHashes(accountId,hashes){this.state.recovery[accountId]=clone(hashes||[]);await this._save();return true}
  async getProfile(accountId){const u=this.state.users[accountId];if(!u)return null;return mergeProfile(this.state.profiles[accountId],accountId)}
  async setProfile(accountId,p){if(!this.state.users[accountId])return false;this.state.profiles[accountId]=mergeProfile(p,accountId);this.state.profiles[accountId].updatedAt=Date.now();await this._save();return true}
  async applyWalletDelta(accountId,txId,chipsDelta,gemsDelta,reason){if(!this.state.users[accountId])return{ok:false,err:'ACCOUNT_NOT_FOUND'};txId=String(txId||'');if(!txId)return{ok:false,err:'TX_ID_REQUIRED'};if(this.state.walletTx[txId])return{ok:true,duplicate:true,profile:await this.getProfile(accountId)};const p=mergeProfile(this.state.profiles[accountId],accountId);p.wallet.chips=Math.max(0,Number(p.wallet.chips||0)+Math.trunc(Number(chipsDelta)||0));p.wallet.gems=Math.max(0,Number(p.wallet.gems||0)+Math.trunc(Number(gemsDelta)||0));p.updatedAt=Date.now();this.state.profiles[accountId]=p;this.state.walletTx[txId]={accountId,reason:String(reason||'').slice(0,160),createdAt:Date.now()};const keys=Object.keys(this.state.walletTx);if(keys.length>10000)for(const k of keys.slice(0,keys.length-10000))delete this.state.walletTx[k];await this._save();return{ok:true,duplicate:false,profile:clone(p)}}
  async recordMatch(matchId,rows){matchId=String(matchId||'');if(!matchId||this.state.processedMatches[matchId])return false;this.state.processedMatches[matchId]=Date.now();for(const r of rows||[]){if(!r||!r.accountId||!this.state.users[r.accountId])continue;const p=mergeProfile(this.state.profiles[r.accountId],r.accountId),s=p.stats;s.matches+=1;s.wins+=r.win?1:0;s.ties+=r.tie?1:0;s.hands+=Math.max(0,Number(r.hands)||0);s.handWins+=Math.max(0,Number(r.handWins)||0);s.bigWins+=Math.max(0,Number(r.bigWins)||0);s.totalPenalty+=Math.max(0,Number(r.totalPenalty)||0);s.majorCount+=Math.max(0,Number(r.majorCount)||0);s.processPenalty+=Math.max(0,Number(r.processPenalty)||0);p.updatedAt=Date.now();this.state.profiles[r.accountId]=p}const mk=Object.keys(this.state.processedMatches);if(mk.length>20000)for(const k of mk.slice(0,mk.length-20000))delete this.state.processedMatches[k];await this._save();return true}
  async ping(){return true}
  status(){return{type:'file',enabled:this.enabled,connected:true,file:this.file,lastSavedAt:this.lastSavedAt,lastError:this.lastError,users:Object.keys(this.state.users).length,sessions:Object.keys(this.state.sessions).length,reports:this.state.reports.length,profiles:Object.keys(this.state.profiles||{}).length}}
}

function safeJson(v){try{return JSON.parse(v)}catch(_){return null}}
class RedisIdentityStore{
  constructor(opts={}){this.url=opts.url||process.env.G17_REDIS_URL||process.env.REDIS_URL||'';this.prefix=String(opts.prefix||process.env.G17_IDENTITY_REDIS_PREFIX||'g17:v165:id').replace(/:+$/,'');this.client=opts.client||null;this.ownsClient=!opts.client;this.connected=false;this.lastError=null}
  k(s){return this.prefix+':'+s}
  async connect(){try{if(!this.client){if(!this.url)throw new Error('G17_REDIS_URL_REQUIRED');let redis;try{redis=require('redis')}catch(_){throw new Error('REDIS_PACKAGE_REQUIRED')};this.client=redis.createClient({url:this.url});this.client.on('error',e=>{this.lastError=String(e&&e.message||e)});await this.client.connect()}await this.client.ping();this.connected=true;this.lastError=null;return true}catch(e){this.connected=false;this.lastError=String(e&&e.message||e);throw e}}
  async close(){if(this.client&&this.ownsClient){try{await this.client.quit()}catch(_){try{this.client.disconnect()}catch(__){}}}this.connected=false}
  async ping(){try{this.connected=(await this.client.ping())==='PONG';return this.connected}catch(e){this.connected=false;this.lastError=String(e&&e.message||e);return false}}
  async createUser(u){const nameKey=this.k('username:'+u.username),ok=await this.client.set(nameKey,u.id,{NX:true});if(!ok)return false;try{await this.client.multi().set(this.k('user:'+u.id),JSON.stringify(u)).set(this.k('public:'+u.publicId),u.id).set(this.k('profile:'+u.id),JSON.stringify(mergeProfile(null,u.id))).exec();return true}catch(e){await this.client.del(nameKey);throw e}}
  async getUserByName(n){const id=await this.client.get(this.k('username:'+n));return id?this.getUserById(id):null}
  async getUserById(id){const s=await this.client.get(this.k('user:'+id));return safeJson(s)}
  async getUserByPublicId(pid){const id=await this.client.get(this.k('public:'+pid));return id?this.getUserById(id):null}
  async updateUser(u){await this.client.set(this.k('user:'+u.id),JSON.stringify(u));await this.client.set(this.k('username:'+u.username),u.id);await this.client.set(this.k('public:'+u.publicId),u.id);return true}
  async putSession(hash,s,ttlMs){await this.client.set(this.k('session:'+hash),JSON.stringify(s),{PX:ttlMs});await this.client.sAdd(this.k('acctsess:'+s.accountId),hash);await this.client.pExpire(this.k('acctsess:'+s.accountId),Math.max(ttlMs,86400000));return true}
  async getSession(hash){return safeJson(await this.client.get(this.k('session:'+hash)))}
  async deleteSession(hash){return Number(await this.client.del(this.k('session:'+hash)))>0}
  async putRefresh(hash,s,ttlMs){await this.client.set(this.k('refresh:'+hash),JSON.stringify(s),{PX:ttlMs});await this.client.sAdd(this.k('acctref:'+s.accountId),hash);await this.client.pExpire(this.k('acctref:'+s.accountId),Math.max(ttlMs,86400000));return true}
  async getRefresh(hash){return safeJson(await this.client.get(this.k('refresh:'+hash)))}
  async deleteRefresh(hash){return Number(await this.client.del(this.k('refresh:'+hash)))>0}
  async revokeAccountSessions(accountId){const sk=this.k('acctsess:'+accountId),rk=this.k('acctref:'+accountId),ss=await this.client.sMembers(sk),rr=await this.client.sMembers(rk),keys=ss.map(h=>this.k('session:'+h)).concat(rr.map(h=>this.k('refresh:'+h))).concat([sk,rk]);if(keys.length)await this.client.del(keys);return ss.length+rr.length}
  async getSanction(accountId){return safeJson(await this.client.get(this.k('sanction:'+accountId)))}
  async setSanction(accountId,s){const k=this.k('sanction:'+accountId);if(!s){await this.client.del(k);return true}await this.client.set(k,JSON.stringify(s));return true}
  async addReport(r){await this.client.lPush(this.k('reports'),JSON.stringify(r));await this.client.lTrim(this.k('reports'),0,4999);return true}
  async listReports(limit=100){return (await this.client.lRange(this.k('reports'),0,Math.max(0,Math.min(500,limit)-1))).map(safeJson).filter(Boolean)}
  async getRecoveryHashes(accountId){return safeJson(await this.client.get(this.k('recovery:'+accountId)))||[]}
  async setRecoveryHashes(accountId,hashes){await this.client.set(this.k('recovery:'+accountId),JSON.stringify(hashes||[]));return true}
  async getProfile(accountId){const u=await this.getUserById(accountId);if(!u)return null;return mergeProfile(safeJson(await this.client.get(this.k('profile:'+accountId))),accountId)}
  async setProfile(accountId,p){if(!await this.getUserById(accountId))return false;const x=mergeProfile(p,accountId);x.updatedAt=Date.now();await this.client.set(this.k('profile:'+accountId),JSON.stringify(x));return true}
  async applyWalletDelta(accountId,txId,chipsDelta,gemsDelta,reason){if(!await this.getUserById(accountId))return{ok:false,err:'ACCOUNT_NOT_FOUND'};const txKey=this.k('wallettx:'+String(txId||'')),profileKey=this.k('profile:'+accountId);if(!txId)return{ok:false,err:'TX_ID_REQUIRED'};if(typeof this.client.eval==='function'){
      const script=`if redis.call('EXISTS',KEYS[1])==1 then return {0,redis.call('GET',KEYS[2]) or ''} end local raw=redis.call('GET',KEYS[2]); local p=nil; if raw then p=cjson.decode(raw) else p={accountId=ARGV[1],createdAt=tonumber(ARGV[2]),updatedAt=tonumber(ARGV[2]),bio='',avatar='default',stats={matches=0,wins=0,ties=0,hands=0,handWins=0,bigWins=0,totalPenalty=0,majorCount=0,processPenalty=0},wallet={chips=100000,gems=500}} end; p.wallet=p.wallet or {chips=100000,gems=500}; p.wallet.chips=math.max(0,(tonumber(p.wallet.chips) or 0)+tonumber(ARGV[3])); p.wallet.gems=math.max(0,(tonumber(p.wallet.gems) or 0)+tonumber(ARGV[4])); p.updatedAt=tonumber(ARGV[2]); local out=cjson.encode(p); redis.call('SET',KEYS[1],ARGV[5],'EX',31536000); redis.call('SET',KEYS[2],out); return {1,out}`;
      const r=await this.client.eval(script,{keys:[txKey,profileKey],arguments:[accountId,String(Date.now()),String(Math.trunc(Number(chipsDelta)||0)),String(Math.trunc(Number(gemsDelta)||0)),String(reason||'').slice(0,160)]});return{ok:true,duplicate:Number(r&&r[0])===0,profile:mergeProfile(safeJson(r&&r[1]),accountId)}}
    const mark=await this.client.set(txKey,String(reason||''),{NX:true});if(!mark)return{ok:true,duplicate:true,profile:await this.getProfile(accountId)};const p=await this.getProfile(accountId);p.wallet.chips=Math.max(0,Number(p.wallet.chips||0)+Math.trunc(Number(chipsDelta)||0));p.wallet.gems=Math.max(0,Number(p.wallet.gems||0)+Math.trunc(Number(gemsDelta)||0));await this.setProfile(accountId,p);return{ok:true,duplicate:false,profile:p}}
  async recordMatch(matchId,rows){const marker=this.k('match:'+String(matchId||''));if(!matchId)return false;if(typeof this.client.eval==='function'){
      const keys=[marker].concat((rows||[]).filter(r=>r&&r.accountId).map(r=>this.k('profile:'+r.accountId))),args=[];for(const r of (rows||[]).filter(r=>r&&r.accountId))args.push(JSON.stringify(r));const script=`if redis.call('EXISTS',KEYS[1])==1 then return 0 end; local now=tostring(redis.call('TIME')[1]); redis.call('SET',KEYS[1],now,'EX',31536000); for i=2,#KEYS do local d=cjson.decode(ARGV[i-1]); local raw=redis.call('GET',KEYS[i]); local p=nil; if raw then p=cjson.decode(raw) else p={accountId=d.accountId,createdAt=tonumber(now)*1000,updatedAt=tonumber(now)*1000,bio='',avatar='default',stats={matches=0,wins=0,ties=0,hands=0,handWins=0,bigWins=0,totalPenalty=0,majorCount=0,processPenalty=0},wallet={chips=100000,gems=500}} end; local s=p.stats or {}; s.matches=(tonumber(s.matches) or 0)+1; s.wins=(tonumber(s.wins) or 0)+(d.win and 1 or 0); s.ties=(tonumber(s.ties) or 0)+(d.tie and 1 or 0); s.hands=(tonumber(s.hands) or 0)+(tonumber(d.hands) or 0); s.handWins=(tonumber(s.handWins) or 0)+(tonumber(d.handWins) or 0); s.bigWins=(tonumber(s.bigWins) or 0)+(tonumber(d.bigWins) or 0); s.totalPenalty=(tonumber(s.totalPenalty) or 0)+(tonumber(d.totalPenalty) or 0); s.majorCount=(tonumber(s.majorCount) or 0)+(tonumber(d.majorCount) or 0); s.processPenalty=(tonumber(s.processPenalty) or 0)+(tonumber(d.processPenalty) or 0); p.stats=s; p.updatedAt=tonumber(now)*1000; redis.call('SET',KEYS[i],cjson.encode(p)); end; return 1`;
      return Number(await this.client.eval(script,{keys,arguments:args}))===1}
    const ok=await this.client.set(marker,String(Date.now()),{NX:true});if(!ok)return false;for(const r of rows||[]){if(!r||!r.accountId)continue;const p=await this.getProfile(r.accountId);if(!p)continue;p.stats.matches++;p.stats.wins+=r.win?1:0;p.stats.ties+=r.tie?1:0;p.stats.hands+=Number(r.hands)||0;p.stats.handWins+=Number(r.handWins)||0;p.stats.bigWins+=Number(r.bigWins)||0;p.stats.totalPenalty+=Number(r.totalPenalty)||0;p.stats.majorCount+=Number(r.majorCount)||0;p.stats.processPenalty+=Number(r.processPenalty)||0;await this.setProfile(r.accountId,p)}return true}
  status(){return{type:'redis',enabled:true,connected:this.connected,prefix:this.prefix,lastError:this.lastError}}
}
module.exports={FileIdentityStore,RedisIdentityStore,defaultProfile,mergeProfile};
